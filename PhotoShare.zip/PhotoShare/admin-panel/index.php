<?php 

if (empty($_GET['page'])) {
    header("Location: $site_url/admin-panel/dashboard");
    exit();
}

$page  = 'dashboard';
$admin = new Admin();

if (!empty($_GET['page'])) {
    $page = $admin::secure($_GET['page']);
}

$page_content = '';
$pages        = array(
    'users' => array(
        'manage-users',
        'manage-verification-requests',
        'blacklist',
        'affiliates-settings',
        'manage-business-requests',
        'manage_fundings'
    ),
    'pro_system' => array(
        'manage-pro-users'
    ),
    'advertisement' => array(
        'ads-settings',
        'payment-requests',
        'manage-ads'
    ),'bank-receipts' => array(
        'bank-receipts'
    ),'earnings' => array(
        'earnings'
    ),
    'posts' => array(
        'manage-posts'
    ),
 
    'reports' => array(
        'profile-reports',
        'post-reports',
    )
);

$admin->pages = $pages;

foreach ($pages as $tab) {
    if (in_array($page, $tab) || $page == 'dashboard') {
        $page_content = $admin->loadPage("$page/content");
        $admin->currp = $page;
        break;
    }
}

if (empty($page_content)) {
    header("Location: $site_url/404");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>
        Admin Panel
    </title>
    
    <link rel="icon" href="media/img/icon.<?php echo $config['favicon_extension']; ?>" type="image/x-icon">

    
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css"> 
    <link href="<?php echo ps_acp_link('plugins/bootstrap/css/bootstrap.css');?>" rel="stylesheet">
    <link href="<?php echo ps_acp_link('plugins/node-waves/waves.css');?>" rel="stylesheet" /> 
    <link href="<?php echo ps_acp_link('plugins/animate-css/animate.css');?>" rel="stylesheet" />
    <link href="<?php echo ps_acp_link('plugins/morrisjs/morris.css');?>" rel="stylesheet" />
    <link href="<?php echo ps_acp_link('css/style.css');?>" rel="stylesheet"> 
    <link href="<?php echo ps_acp_link('css/themes/all-themes.css');?>" rel="stylesheet" />
    <link href="<?php echo ps_acp_link('plugins/bootstrap-toggle/bootstrap-toggle.min.css');?>" rel="stylesheet" />
    <link href="<?php echo ps_acp_link('plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css'); ?>" rel="stylesheet">
    <link href="<?php echo ps_acp_link('plugins/bootstrap-select/css/bootstrap-select.css');?>" rel="stylesheet" />
    <script src="<?php echo ps_acp_link('plugins/jquery/jquery.min.js');?>"></script>
    <script>
        function acpajax_url(path) {
            return '<?php echo($config['site_url']); ?>/aj/admin/' + path;
        }
    </script>
</head>

<body class="theme-red">   
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>ça arrive</p>
        </div>
    </div>
    
    
    <div class="overlay"></div>
    
    
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    
    
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="<?php echo $config['site_url']; ?>">
                    <strong><?php echo $config['site_name']; ?></strong> -->
                </a>
            </div>
        </div>
    </nav>
    
    <section>
        <aside id="leftsidebar" class="sidebar">       
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo $me['avatar']; ?>" width="48" height="48" alt="<?php echo $me['name']; ?>" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $me['username']; ?></div>
                    <div class="email"><?php echo $me['email']; ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li>
                                <a href="<?php echo $me['url']; ?>">
                                    <i class="material-icons">person</i> Mon profile
                                </a>
                            </li>
                            <li role="seperator" class="divider"></li>
                            <li>
                                <a href="<?php echo $me['url']; ?>/followers">
                                    <i class="material-icons">group</i> Mes Followers
                                </a>
                            </li>
                            <li role="seperator" class="divider"></li>
                            <li>
                                <a href="<?php echo $site_url; ?>/signout">
                                    <i class="material-icons">input</i> Se deconnecter
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="menu">
                <ul class="list">
                    <li class="<?php echo $admin->activeMenu('dashboard'); ?>">
                        <a href="<?php echo ps_acp_link('dashboard');?>">
                            <i class="material-icons">collections</i>
                            <span>Tableau de bord</span>
                        </a>
                    </li>
                    <li class="<?php echo $admin->activeMenu('users'); ?>">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">account_circle</i>
                            <span>Utilisateurs</span>
                        </a>
                        <ul class="ml-menu">
                            <li class="<?php echo $admin->activeMenu('manage-users'); ?>">
                                <a href="<?php echo ps_acp_link('manage-users'); ?>" class="waves-effect waves-block">
                                    Gérer les utilisateurs
                                </a>
                            </li>
                            <li class="<?php echo $admin->activeMenu('manage-verification-requests'); ?>">
                                <a href="<?php echo ps_acp_link('manage-verification-requests'); ?>" class="waves-effect waves-block">
                                    Gérer les véérfications de compte
                                </a>
                            </li>
                            <li class="<?php echo $admin->activeMenu('manage-business-requests'); ?>">
                                <a href="<?php echo ps_acp_link('manage-business-requests'); ?>" class="waves-effect waves-block">
                                    Gérer les demandes pro
                                </a>
                            </li> 
                        </ul>
                        
                    </li>
                    <li class="<?php echo $admin->activeMenu('pro_system'); ?>">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">stars</i>
                            <span>Compte pro</span>
                        </a>
                        <ul class="ml-menu">

                            <li class="<?php echo $admin->activeMenu('manage-pro-users'); ?>">
                                <a href="<?php echo ps_acp_link('manage-pro-users'); ?>" class="waves-effect waves-block">
                                    Gérer les comptes pro
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="<?php echo $admin->activeMenu('posts'); ?>">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">collections</i>
                            <span>Posts</span>
                        </a>
                        <ul class="ml-menu">
                            <li class="<?php echo $admin->activeMenu('manage-posts'); ?>">
                                <a href="<?php echo ps_acp_link('manage-posts'); ?>" class="waves-effect waves-block">
                                   Gestion des posts
                                </a>
                            </li>
                        </ul>
                    </li>
            </div>
            <div class="legal">
                <div class="copyright">
                    &copy;2019 : Besbas, Camus & Houni <a href="<?php echo $site_url;?>"><?php echo $config['site_name']; ?></a>.
                </div>

            </div> 
        </aside>
    </section>

    <section class="content">
        <div class="container-fluid">
            <?php if (is_dir(dirname(dirname(__FILE__)).DIRECTORY_SEPARATOR."install")) { ?>
              <div class="alert alert-danger">
                <i class="fa fa-fw fa-exclamation-triangle"></i>
              </div>
            <?php } ?>
            <?php echo $page_content; ?>
        </div>
    </section>
    
    <script src="<?php echo ps_acp_link('plugins/bootstrap/js/bootstrap.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/buttons.flash.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/jszip.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/pdfmake.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/vfs_fonts.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/buttons.html5.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-datatable/extensions/export/buttons.print.min.js'); ?>"></script>
    <script src="<?php echo ps_acp_link('js/pages/tables/jquery-datatable.js'); ?>"></script>
    
    <script src="<?php echo ps_acp_link('plugins/bootstrap-select/js/bootstrap-select.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-slimscroll/jquery.slimscroll.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/node-waves/waves.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-countto/jquery.countTo.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/raphael/raphael.min.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/morrisjs/morris.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/chartjs/Chart.bundle.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-sparkline/jquery.sparkline.js');?>"></script>
    <script src="<?php echo ps_acp_link('js/admin.js');?>"></script>
    <script src="<?php echo ps_acp_link('js/demo.js');?>"></script>
    <script src="<?php echo ps_acp_link('js/script.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/bootstrap-toggle/bootstrap-toggle.min.js');?>"></script>
    <script src="<?php echo ps_acp_link('plugins/jquery-form/jquery-form.v3.51.0.js');?>"></script>
</body>

</html>