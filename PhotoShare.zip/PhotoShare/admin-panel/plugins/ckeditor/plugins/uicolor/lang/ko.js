/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ko",{title:"UI 색상 선택기",preview:"미리보기",config:"이 문자열을 config.js 에 붙여넣으세요",predefined:"미리 정의된 색상"});